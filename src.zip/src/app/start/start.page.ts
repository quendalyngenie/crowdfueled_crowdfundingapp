import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth/auth.service';

@Component({
  selector: 'app-start',
  templateUrl: './start.page.html',
  styleUrls: ['./start.page.scss'],
})
export class StartPage implements OnInit {
  userId: string;
  type: string;

  constructor(private authService: AuthService) {
    this.userId = this.authService.getId();
    this.authService.getSUTById(this.userId)
      .then(data => {
        this.type = data;
      })
  }

  ngOnInit() {
  }

}
