import { Component, OnInit } from '@angular/core';
import { Blog } from 'src/app/services/blog';
import { BlogService } from 'src/app/services/blog.service';



@Component({
  selector: 'app-personalblog',
  templateUrl: './personalblog.page.html',
  styleUrls: ['./personalblog.page.scss'],
})
export class PersonalblogPage implements OnInit {
  blog: Blog[];

  constructor(private blogService: BlogService) {
    this.blogService.getBlogs()
      .subscribe(data => {
        this.blog = data;
      });
  }

  ngOnInit() {
  }
  delete(item: Blog) {
    this.blogService.delete(item);
  }

}