import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { FirebaseCampaignService } from 'src/app/services/services/services/firebase-campaign.service';
import firebase from 'firebase/app';
import 'firebase/firestore';



@Component({
  selector: 'app-campaign',
  templateUrl: './campaign.page.html',
  styleUrls: ['./campaign.page.scss']
})

export class CampaignPage {
  campaigns: any;
  campaignImages: { [key: string]: string } = {};
  filteredCampaigns: any;
  totalTransactions: number = 0;

  constructor(private campaignService: FirebaseCampaignService, private navCtrl: NavController) {

    // this.campaignService.getCampaigns().subscribe(campaigns => {
    //   this.campaigns = campaigns;
    //   this.filteredCampaigns = campaigns;
    //   campaigns.forEach(campaign => {
    //     this.campaignService.getImageUrl(campaign.image).then(url => this.campaignImages[campaign.id] = url);
    //   });
    // });
  }

  search(campaign) {
    // Get the text typed by the user in the search bar
    const text = campaign.target.value;

    if (text && text.trim() !== '') {
      // Use all campaigns to filter
      this.filteredCampaigns = this.campaigns.filter(
        campaign => campaign.prjName.toLowerCase().includes(text.toLowerCase()));
    } else {
      // Blank text, clear the search, show all campaigns
      this.filteredCampaigns = this.campaigns;
    }
  }


  ngOnInit() {
    this.campaignService.getCampaigns().subscribe(campaigns => {
      this.campaigns = campaigns;
      this.filteredCampaigns = campaigns;
      campaigns.forEach(campaign => {
        this.campaignService.getImageUrl(campaign.image).then(url => this.campaignImages[campaign.id] = url);
        this.calculateProgress(campaign);
      });
    });
  }
  
  calculateProgress(campaign) {
    let totalTransactions = 0;
    firebase.firestore().collection("Transaction").where("prjId", "==", campaign.id).get().then(querySnapshot => {
      querySnapshot.forEach(doc => {
        totalTransactions += Number(doc.data().txnAmt); // convert string to number
      });
  
      // Calculate progress percentage
      campaign.progress = Math.floor(totalTransactions / campaign.target * 100);
      campaign.totalTransactions = totalTransactions;
    });
  }

  
  // if txnAmt is number
  // calculateProgress(campaign) {
  //   let totalTransactions = 0;
  //   firebase.firestore().collection("Transaction").where("prjId", "==", campaign.id).get().then(querySnapshot => {
  //     querySnapshot.forEach(doc => {
  //       totalTransactions += doc.data().txnAmt;
  //     });
  
  //     // Calculate progress percentage
  //     campaign.progress = Math.floor(totalTransactions / campaign.target * 100);
  //     campaign.totalTransactions = totalTransactions;
  //   });
  // }
  

  goToCampaignDetail(campaignId: string) {
    this.navCtrl.navigateForward(`/campaign-detail/${campaignId}`);
  }

  favoriteCampaign(campaignId: string) {
    this.campaignService.getCampaign(campaignId).subscribe(campaign => {
      const updatedCampaign = { ...campaign, favorites: !campaign.favorites };
      this.campaignService.updateCampaign(campaignId, updatedCampaign);
      // Update the campaign object and the campaigns array directly
      const index = this.campaigns.findIndex(c => c.id === campaignId);
      this.campaigns[index].favorites = !this.campaigns[index].favorites;
    });
  }

}